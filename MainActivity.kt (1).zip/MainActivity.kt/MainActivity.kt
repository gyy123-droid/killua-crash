package com.killua.crash.lab

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

val CyberBlack = Color(0xFF050508)
val PanelDark = Color(0xFF101018)
val NeonRed = Color(0xFFFF1E38)
val NeonBlue = Color(0xFF00E5FF)
val TextMuted = Color(0xFF8A99AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KilluaTheme {
                val navController = rememberNavController()
                var logs by remember { mutableStateOf(listOf<String>()) }
                var bugs by remember { mutableStateOf(listOf<String>()) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberBlack
                ) {
                    NavHost(navController = navController, startDestination = "dashboard") {
                        composable("dashboard") { DashboardScreen(navController) }
                        composable("target_number") { TargetNumberScreen(navController) { msg -> logs = logs + "[${getTime()}] $msg" } }
                        composable("crash_lab") { CrashLabScreen(navController) { msg -> logs = logs + "[${getTime()}] $msg" } }
                        composable("wa_compat") { WaCompatScreen(navController) { msg -> logs = logs + "[${getTime()}] $msg" } }
                        composable("stress_test") { StressTestScreen(navController) { bug -> bugs = bugs + "[${getTime()}] $bug" } }
                        composable("bug_analyzer") { BugAnalyzerScreen(navController, bugs) { bugs = emptyList() } }
                        composable("target_sim") { TargetSimScreen(navController) { msg -> logs = logs + "[${getTime()}] $msg" } }
                        composable("vip_dashboard") { VipDashboardScreen(navController) }
                    }
                }
            }
        }
    }
}

fun getTime(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

@Composable
fun KilluaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonRed,
            secondary = NeonBlue,
            background = CyberBlack,
            surface = PanelDark
        ),
        content = content
    )
}

@Composable
fun DashboardScreen(navController: NavController) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚡ KILLUA // CRASH LAB",
                color = NeonBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace
            )
            Box(
                modifier = Modifier
                    .border(1.dp, NeonRed, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(text = "SECURE SANDBOX", color = NeonRed, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, NeonBlue.copy(alpha = borderAlpha), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawLine(NeonBlue, Offset(w * 0.15f, h * 0.2f), Offset(w * 0.3f, h * 0.5f), strokeWidth = 3f)
                drawLine(NeonBlue, Offset(w * 0.3f, h * 0.5f), Offset(w * 0.25f, h * 0.45f), strokeWidth = 3f)
                drawLine(NeonBlue, Offset(w * 0.25f, h * 0.45f), Offset(w * 0.5f, h * 0.85f), strokeWidth = 5f)
                drawLine(NeonRed.copy(alpha = 0.6f), Offset(w * 0.7f, h * 0.1f), Offset(w * 0.65f, h * 0.5f), strokeWidth = 2f)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SYSTEM STATUS: ONLINE", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text("GODSPEED CORE ACTIVE", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            ModuleCard("🎯 Target Number Analyzer", "Analisis format & parameter nomor telepon", NeonRed) { navController.navigate("target_number") }
            ModuleCard("⚡ Crash Lab", "Simulasi visual crash & analisis exception lokal", NeonBlue) { navController.navigate("crash_lab") }
            ModuleCard("🛡️ WhatsApp Compatibility Lab", "Analisis kompatibilitas & performa non-invasif", NeonRed) { navController.navigate("wa_compat") }
            ModuleCard("⚙️ Stress Test", "Uji beban & responsivitas UI aplikasi sendiri", NeonBlue) { navController.navigate("stress_test") }
            ModuleCard("🧪 Bug Analyzer", "Pusat pencatatan error dan diagnostik lokal", NeonRed) { navController.navigate("bug_analyzer") }
            ModuleCard("🎯 Target Simulator", "Simulasi parameter perangkat target fiktif", NeonBlue) { navController.navigate("target_sim") }
            ModuleCard("💎 VIP Dashboard", "Panel statistik dan kontrol tingkat lanjut", NeonRed) { navController.navigate("vip_dashboard") }
        }
    }
}

@Composable
fun ModuleCard(title: String, desc: String, accent: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelDark, RoundedCornerShape(8.dp))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
fun TargetNumberScreen(navController: NavController, onLog: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var phoneNumber by remember { mutableStateOf("+62") }
    var isValidFormat by remember { mutableStateOf<Boolean?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var statusMessage by remember { mutableStateOf("Ready for non-invasive parameter analysis.") }

    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { uri ->
        uri?.let {
            val cursor = context.contentResolver.query(it, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val hasPhoneIndex = cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)
                val idIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID)
                val hasPhone = if (hasPhoneIndex != -1) cursor.getString(hasPhoneIndex) else "0"
                val id = if (idIndex != -1) cursor.getString(idIndex) else ""

                if (hasPhone == "1") {
                    val pCursor = context.contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(id),
                        null
                    )
                    if (pCursor != null && pCursor.moveToFirst()) {
                        val numIndex = pCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (numIndex != -1) {
                            val pickedNumber = pCursor.getString(numIndex).replace(" ", "").replace("-", "")
                            phoneNumber = if (pickedNumber.startsWith("0")) "+62" + pickedNumber.substring(1) else pickedNumber
                            onLog("Contact selected: $phoneNumber")
                        }
                        pCursor.close()
                    }
                }
                cursor.close()
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            contactPickerLauncher.launch(null)
        } else {
            statusMessage = "Contact permission denied by user."
            onLog("Permission READ_CONTACTS denied.")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        
        Text("🎯 TARGET NUMBER ANALYZER", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Modul analisis format & kompatibilitas nomor secara lokal dan aman.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { input ->
                phoneNumber = input
                isValidFormat = input.matches(Regex("^\\+[1-9]\\d{7,14}\$"))
            },
            label = { Text("Phone Number (+CountryCode)", color = TextMuted) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonBlue,
                unfocusedBorderColor = PanelDark,
                focusedLabelColor = NeonBlue,
                cursorColor = NeonBlue
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
                if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                    contactPickerLauncher.launch(null)
                } else {
                    permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = PanelDark),
            border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text("📇 SELECT CONTACT", color = NeonBlue, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, if (isValidFormat == false) NeonRed else NeonBlue, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            Column {
                Text("Target Input: $phoneNumber", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = when (isValidFormat) {
                        true -> "Validation: VALID E.164 FORMAT"
                        false -> "Validation: INVALID FORMAT (e.g., +628123456789)"
                        null -> "Validation: PENDING INPUT"
                    },
                    color = if (isValidFormat == true) NeonBlue else if (isValidFormat == false) NeonRed else TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("Status: $statusMessage", color = Color.White, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = NeonRed,
                    trackColor = CyberBlack,
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    if (isValidFormat != true) {
                        statusMessage = "Error: Input valid number before starting analysis."
                        return@Button
                    }
                    if (!isAnalyzing) {
                        isAnalyzing = true
                        scope.launch {
                            statusMessage = "Validating routing parameter..."
                            progress = 0.25f
                            delay(600)
                            statusMessage = "Simulating local sandbox response..."
                            progress = 0.65f
                            delay(600)
                            statusMessage = "Analysis completed. 0 vulnerabilities or payload triggers."
                            progress = 1.0f
                            isAnalyzing = false
                            onLog("Target Analysis completed for $phoneNumber")
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("START ANALYSIS", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    isAnalyzing = false
                    progress = 0f
                    statusMessage = "Process halted by user."
                    onLog("Target Analysis stopped manually.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("STOP", fontWeight = FontWeight.Bold, color = TextMuted)
            }
        }
    }
}

@Composable
fun CrashLabScreen(navController: NavController, onLog: (String) -> Unit) {
    var statusText by remember { mutableStateOf("Idle - Ready to analyze.") }
    var isRunning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Text("⚡ CRASH LAB", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Simulasi visual penanganan exception dalam lingkungan tertutup.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, NeonRed, RoundedCornerShape(12.dp))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(statusText, color = NeonBlue, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = NeonRed,
                    trackColor = CyberBlack,
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    if (!isRunning) {
                        isRunning = true
                        scope.launch {
                            statusText = "Initializing Godspeed buffer..."
                            progress = 0.2f
                            delay(600)
                            statusText = "Injecting safe test exception..."
                            progress = 0.6f
                            delay(600)
                            statusText = "Exception caught & handled locally."
                            progress = 1.0f
                            isRunning = false
                            onLog("Crash Lab simulation completed safely.")
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("START", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = {
                    isRunning = false
                    statusText = "Simulation aborted."
                    progress = 0f
                    onLog("Crash Lab stopped manually.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("STOP", fontWeight = FontWeight.Bold, color = TextMuted)
            }
        }
    }
}

@Composable
fun WaCompatScreen(navController: NavController, onLog: (String) -> Unit) {
    var analysisResult by remember { mutableStateOf("Pending scan...") }
    var isScanning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Text("🛡️ WA COMPATIBILITY LAB", color = NeonBlue, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Pemeriksaan kompatibilitas & performa non-invasif menggunakan lingkungan sandbox sendiri.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, NeonBlue, RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column {
                Text("Target Module: Local Wrapper Environment", color = Color.White, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Status: $analysisResult", color = NeonBlue, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (!isScanning) {
                    isScanning = true
                    scope.launch {
                        analysisResult = "Scanning local database structures..."
                        delay(800)
                        analysisResult = "Checking protocol boundaries... Secure."
                        delay(800)
                        analysisResult = "Compatibility check passed. Zero external impact."
                        isScanning = false
                        onLog("WhatsApp Compatibility Lab test completed successfully.")
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonBlue),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text("START ANALYSIS", fontWeight = FontWeight.Bold, color = CyberBlack)
        }
    }
}

@Composable
fun StressTestScreen(navController: NavController, onBug: (String) -> Unit) {
    var intensity by remember { mutableStateOf(3) }
    var testStatus = remember { mutableStateOf("Ready") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Text("⚙️ STRESS TEST", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Uji beban operasional UI dan memori aplikasi internal.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(20.dp))
        Text("Intensity Level: $intensity / 10", color = Color.White)
        Slider(
            value = intensity.toFloat(),
            onValueChange = { intensity = it.toInt() },
            valueRange = 1f..10f,
            steps = 8,
            colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                testStatus.value = "Executing stress cycle (Level $intensity)..."
                onBug("Stress test performed at level $intensity. System stable.")
                testStatus.value = "Completed successfully. No memory leaks."
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text("START TEST", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Log: ${testStatus.value}", color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
fun BugAnalyzerScreen(navController: NavController, bugs: List<String>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("🧪 BUG ANALYZER", color = NeonBlue, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (bugs.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Clear", color = TextMuted) }
            }
        }
        Text("Riwayat diagnostik dan catatan error lokal.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(16.dp))

        if (bugs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No bug entries recorded.", color = TextMuted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                items(bugs) { bug ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PanelDark, RoundedCornerShape(6.dp))
                            .border(1.dp, NeonBlue.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(12.dp)
                    ) {
                        Text(bug, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun TargetSimScreen(navController: NavController, onLog: (String) -> Unit) {
    var targetStatus by remember { mutableStateOf("Target Fiktif: Android Virtual Node #01 (Offline)") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Text("🎯 TARGET SIMULATOR", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Simulasi pemantauan perangkat target fiktif untuk keperluan demonstrasi.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, NeonRed, RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column {
                Text("Node ID: KILLUA-SIM-X", color = NeonBlue, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(targetStatus, color = Color.White, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    targetStatus = "Target Node Connected (Monitoring Mode Active)"
                    onLog("Target Simulator analysis started.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("START ANALYSIS", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = {
                    targetStatus = "Target Node Disconnected (Idle)"
                    onLog("Target Simulator stopped.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("STOP", fontWeight = FontWeight.Bold, color = TextMuted)
            }
        }
    }
}

@Composable
fun VipDashboardScreen(navController: NavController) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BackButton(navController)
        Spacer(modifier = Modifier.height(16.dp))
        Text("💎 VIP DASHBOARD", color = NeonBlue, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Panel eksklusif bertema Godspeed Killua Zoldyck.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelDark, RoundedCornerShape(12.dp))
                .border(1.dp, NeonBlue, RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column {
                Text("⚡ Godspeed Protocol: UNLOCKED", color = NeonRed, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("CPU Core Allocation: 100% Optimized", color = Color.White, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Sandbox Security: Maximum Level", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun BackButton(navController: NavController) {
    Text(
        text = "← BACK",
        color = NeonBlue,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clickable { navController.popBackStack() }
            .padding(vertical = 4.dp)
    )
}
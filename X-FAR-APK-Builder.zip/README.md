# X-FAR Android APK Builder

This is an Android app shell with a high-resolution dark red/black interface and local-only Simulation, Tools, VIP demo features.

## Important
- No WhatsApp connection, no target phone number, no message sending, and no network calls in the app.
- VIP is a visual demo toggle only.
- This ZIP is Android source, not a precompiled APK.

## Build from a phone using GitHub Actions
1. Create/sign in to GitHub in your mobile browser.
2. Create a new repository (Public or Private).
3. Upload the contents of this folder to the repository, keeping `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab and allow workflows if prompted.
5. Run **Build X-FAR APK** with **Run workflow** (or push to main).
6. When it finishes, open the workflow run, scroll to **Artifacts**, and download `X-FAR-debug-apk`.
7. Extract the artifact ZIP; install `app-debug.apk` on your Android phone if Android allows installation from that source.

Note: Android builds normally need the Gradle wrapper. This project includes a GitHub workflow fallback to system Gradle; if the runner's Gradle version is incompatible, a Gradle wrapper should be added by a cloud build environment. Do not use untrusted third-party APK build sites.

package com.xfar.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.graphics.Color
import android.view.View
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    private var webView: WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,8,11)
        window.navigationBarColor = Color.rgb(8,8,11)
        window.decorView.systemUiVisibility = 0
        setContent {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = false
                        settings.allowFileAccess = true
                        settings.allowContentAccess = false
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        setBackgroundColor(Color.rgb(8,8,11))
                        loadUrl("file:///android_asset/index.html")
                        webView = this
                    }
                }
            )
            BackHandler(enabled = webView?.canGoBack() == true) { webView?.goBack() }
        }
    }
    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}